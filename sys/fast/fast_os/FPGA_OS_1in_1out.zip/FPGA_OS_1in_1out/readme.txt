2019.7.30:
此FPGA_OS的版本与UM的接口为1组输入1组输出的版本，其中CPU与PORT的输入分组数据分先经过MUX进行汇聚后输入给UM，输出时输出分组通过DMUX模块分配给CPU或不同PORT。
此文件夹包括2个文件，分别为：FPGA_OS.edf、FPGA_OS.v。其中FPGA_OS.edf综合后的edf网表文件以及接口声明的FPGA_OS.v。