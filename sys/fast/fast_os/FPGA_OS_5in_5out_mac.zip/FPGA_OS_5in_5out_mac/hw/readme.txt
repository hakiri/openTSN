﻿2019.11.08:
此FPGA_OS的版本与UM的接口为5组输入5组输出的版本，1组CPU数据通路和4组接口数据通路。此版本新增MAC地址配置功能，用户可为openbox-s4设备配置固定的MAC地址。48位的MAC地址信号已引入到um模块顶层，用户可以声明该信号并调用。

此文件夹包括3个文件，分别为：
1.FPGA_OS_wrapper.edf;
2.FPGA_OS_wrapper.v;
3.FPGA_OS_wrapper.xdc;

其中FPGA_OS_wrapper.edf为综合后的edf网表文件，FPGA_OS_wrapper.v为接口声明的文件，FPGA_OS_wrapper.xdc为约束文件。

使用方法：
	
     使用时只需将以上3个文件添加到工程，并根据FPGA_OS_wrapper.v中声明的接口进行实例化，根据FPGA_OS使用文档正常与用户逻辑进行连接。