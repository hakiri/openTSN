﻿2019.7.30:
此FPGA_OS的版本与UM的接口为1组输入4组输出的版本，无CPU的通路，PORT的输入分组数据分先经过MUX进行汇聚后输入给UM，输出时输出分组由UM控制输出给不同PORT。
此文件夹包括2个文件，分别为：FPGA_OS.edf、FPGA_OS.v。其中FPGA_OS.edf综合后的edf网表文件以及接口声明的FPGA_OS.v。