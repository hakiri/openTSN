﻿2019.10.10:
此FPGA_OS的版本与UM的接口为1组输入4组输出的版本，无CPU的通路，PORT的输入分组数据分先经过MUX进行汇聚后输入给UM，输出时输出分组由UM控制输出给不同PORT。
此文件夹包括3个文件，分别为：
1.FPGA_OS_wrapper.edf;
2.FPGA_OS_wrapper.v;
3.FPGA_OS_wrapper.xdc;

其中FPGA_OS_wrapper.edf为综合后的edf网表文件，FPGA_OS_wrapper.v为接口声明的文件，FPGA_OS_wrapper.xdc为约束文件。
使用方法：
	使用时只需将以上3个文件添加到工程，并根据FPGA_OS_wrapper.v中声明的接口进行实例化，根据FPGA_OS使用文档正常与用户逻辑进行连接。