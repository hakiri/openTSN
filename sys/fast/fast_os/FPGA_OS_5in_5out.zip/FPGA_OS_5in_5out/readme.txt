2019.7.30:
此FPGA_OS的版本与UM的接口为5组输入5组输出的版本，其中5组接口分别为1组CPU2UM/UM2CPU，4组PORTx2UM/UM2PORTx（x为0-3）。
此文件夹包括2个文件，分别为：FPGA_OS.edf、FPGA_OS.v。其中FPGA_OS.edf综合后的edf网表文件以及接口声明的FPGA_OS.v。