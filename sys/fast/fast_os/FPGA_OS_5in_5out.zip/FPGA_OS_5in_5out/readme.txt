﻿2019.7.30:
此FPGA_OS的版本与UM的接口为5组输入5组输出的版本，其中5组接口分别为1组CPU2UM/UM2CPU，4组PORTx2UM/UM2PORTx（x为0-3）。
2019.8.16：
修改UDO的代码中透明时间的计算逻辑，使透明时间的值在转发PTP TC域的时计算而非之前的在报文输出第一拍计算。
此文件夹包括7个文件，分别为：
1.FPGA_OS_wrapper.edf;
2.FPGA_OS_wrapper.v;
3.FPGA_OS_wrapper.xdc;
4.xxx_tri_mode_ethernet_mac_v9_0xxx.edn。

其中FPGA_OS_wrapper.edf为综合后的edf网表文件，xxx_tri_mode_ethernet_mac_v9_0xxx.edn为4个接口网表文件、FPGA_OS_wrapper.v为接口声明的文件、FPGA_OS_wrapper.xdc为约束文件。
使用方法：
	使用时只需将以上7个文件添加到工程，并根据FPGA_OS_wrapper.v中声明的接口进行实例化，根据FPGA_OS使用文档正常与用户逻辑进行连接。